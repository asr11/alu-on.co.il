<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'db54_alu_on' );

/** Database username */
define( 'DB_USER', 'u54_alu_on' );

/** Database password */
define( 'DB_PASSWORD', 'iCaKXEGLXjhXFpVW' );

/** Database hostname */
define( 'DB_HOST', 'localhost:3306' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'Iyr<|Gl|0KG-o];DnYj/<6^,m@L=2Vmw}d=$j/~fpR3*%3Hj ?>4u}+Bb!gRfZHW' );
define( 'SECURE_AUTH_KEY',   '3JKi<v~sr*6-==B!5.7hVf-.-HN/o`M5F!F1_ -B3s*dE,F;xBqlr3]{]@msX0AV' );
define( 'LOGGED_IN_KEY',     'Y[aEaEf ~MbG?Co^rerZi<tx/]J`Hq$&F+&/O;o+5Y94F6$_EkS)HYOF7P/DR]?Y' );
define( 'NONCE_KEY',         '%io]Y*tkAdu|Msx<%h^XwP#~)kk@5a{vF5NjNv4aw/<yv&sW=:(VJt1u; ~z_f/F' );
define( 'AUTH_SALT',         '}HMyL2YS>Z*wNwIud#ui/U>?63] |h%WoiY!Te[UShh `1-OFk?g)^yp?6Mdl@({' );
define( 'SECURE_AUTH_SALT',  '-f%U16hPyxX(m(u[MtH_RZ8;%GA)HJ Rg/nQk5}uokwDgj9:s}:3bZBe`nKMRcfk' );
define( 'LOGGED_IN_SALT',    ',2U BnLC;yB>W^fU:a.fb/iuOoJL6?X&d0F_=X7M6.u,nx<^6bxzGZ#A7aAV&[ZG' );
define( 'NONCE_SALT',        '^P3R9[Toh}_XaQ)qO_TZ|]6N+v(8vDtn;mcY3]oYBnQduq~bH!%7=94Jt$Ww t$(' );
define( 'WP_CACHE_KEY_SALT', 'w30O/nsh6eM,7.y[8*NJFhD$B8ST!#ZxUfi)%6?Ehh%EU.UTV)S^:>||J#Y,WDCa' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'ismy_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'RT_WP_NGINX_HELPER_CACHE_PATH', '/etc/nginx/cache/alu-on.co.il' );
define( 'WP_REDIS_PASSWORD', ["u54_alu_on", "kACYIuL9v7vWmL9FYiqTNf4kSsfEPOoi"] );
define( 'WP_REDIS_DISABLE_BANNERS', 'true' );
define( 'WP_REDIS_PREFIX', 'redis:37060:244761:alu-on-co-il' );
define( 'DISABLE_WP_CRON', true );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
