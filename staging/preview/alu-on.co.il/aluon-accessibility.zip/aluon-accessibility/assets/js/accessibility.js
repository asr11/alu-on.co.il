/**
 * Alu-on Accessibility Plugin JavaScript (WCAG 2.1 AA / ת"י 5568)
 * LocalStorage state persistence + Screen Reader live announcements
 */

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('aluonA11yBtn');
  const panel = document.getElementById('aluonA11yPanel');
  const closeBtn = document.getElementById('aluonA11yClose');
  const liveRegion = document.getElementById('aluonA11yLive');

  if (!btn || !panel) return;

  const STORAGE_KEY = 'aluon_a11y_prefs';

  // Toggle Panel Open/Close
  btn.addEventListener('click', () => {
    const isOpen = panel.classList.toggle('open');
    panel.setAttribute('aria-hidden', !isOpen);
    btn.setAttribute('aria-expanded', isOpen);
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      panel.classList.remove('open');
      panel.setAttribute('aria-hidden', 'true');
      btn.setAttribute('aria-expanded', 'false');
    });
  }

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && panel.classList.contains('open')) {
      panel.classList.remove('open');
      panel.setAttribute('aria-hidden', 'true');
      btn.focus();
    }
  });

  // Action mapping
  const actions = {
    'font-inc': { class: 'a11y-font-lg', label: 'הגדלת טקסט' },
    'font-dec': { class: 'a11y-font-sm', label: 'הקטנת טקסט' },
    'readable-font': { class: 'a11y-readable-font', label: 'פונט קריא' },
    'contrast': { class: 'a11y-high-contrast', label: 'ניגודיות גבוהה' },
    'invert': { class: 'a11y-invert', label: 'ניגודיות הפוכה' },
    'grayscale': { class: 'a11y-grayscale', label: 'גווני אפור' },
    'light-bg': { class: 'a11y-light-bg', label: 'רקע בהיר' },
    'links': { class: 'a11y-links', label: 'הדגשת קישורים' },
    'cursor': { class: 'a11y-cursor', label: 'סמן מוגדל' },
    'stop-anim': { class: 'a11y-stop-anim', label: 'עצירת תנועה' }
  };

  // Load Saved State from LocalStorage
  function loadSavedPrefs() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
      saved.forEach(actionKey => {
        if (actions[actionKey]) {
          document.body.classList.add(actions[actionKey].class);
          const optBtn = panel.querySelector(`[data-action="${actionKey}"]`);
          if (optBtn) optBtn.classList.add('active');
        }
      });
    } catch (err) {
      console.warn('Aluon A11y: Could not read LocalStorage', err);
    }
  }

  // Save State to LocalStorage
  function savePrefs() {
    try {
      const activeActions = [];
      Object.keys(actions).forEach(actionKey => {
        if (document.body.classList.contains(actions[actionKey].class)) {
          activeActions.push(actionKey);
        }
      });
      localStorage.setItem(STORAGE_KEY, JSON.stringify(activeActions));
    } catch (err) {
      console.warn('Aluon A11y: Could not save to LocalStorage', err);
    }
  }

  // Screen Reader Live Announcements
  function announce(msg) {
    if (liveRegion) {
      liveRegion.textContent = '';
      setTimeout(() => { liveRegion.textContent = msg; }, 100);
    }
  }

  // Event Delegation for Options
  panel.querySelectorAll('.aluon-a11y-opt[data-action]').forEach(optBtn => {
    optBtn.addEventListener('click', () => {
      const actionKey = optBtn.getAttribute('data-action');

      if (actionKey === 'reset') {
        Object.keys(actions).forEach(k => {
          document.body.classList.remove(actions[k].class);
          const b = panel.querySelector(`[data-action="${k}"]`);
          if (b) b.classList.remove('active');
        });
        localStorage.removeItem(STORAGE_KEY);
        announce('הגדרות הנגישות אופסו');
        return;
      }

      if (actionKey === 'font-inc') {
        document.body.classList.remove(actions['font-dec'].class);
        const fontDecBtn = panel.querySelector('[data-action="font-dec"]');
        if (fontDecBtn) fontDecBtn.classList.remove('active');
      } else if (actionKey === 'font-dec') {
        document.body.classList.remove(actions['font-inc'].class);
        const fontIncBtn = panel.querySelector('[data-action="font-inc"]');
        if (fontIncBtn) fontIncBtn.classList.remove('active');
      }

      if (actions[actionKey]) {
        const isActive = document.body.classList.toggle(actions[actionKey].class);
        optBtn.classList.toggle('active', isActive);
        announce(`${actions[actionKey].label} ${isActive ? 'מופעל' : 'מבוטל'}`);
        savePrefs();
      }
    });
  });

  loadSavedPrefs();
});
